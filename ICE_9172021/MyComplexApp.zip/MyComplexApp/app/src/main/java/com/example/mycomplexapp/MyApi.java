package com.example.mycomplexapp;

import android.content.Context;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class MyApi {
    public interface SimpleCallback<T> {
        void callback(T data) throws JSONException;
    }
    public static JsonArrayRequest getObject(SimpleCallback<JSONArray> finishedCallback, String link) {
        JsonArrayRequest request3 = new JsonArrayRequest(Request.Method.GET, link, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

                try {
                    finishedCallback.callback(response);
                 //   System.out.println(response);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                //   adapter.notifyDataSetChanged();
            }
        }, error -> System.out.println(error.toString()));
        return request3;
    }
    public static StringRequest StringRequest(Context c, String url){
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray jsonObject = new JSONArray(response);
                    Toast.makeText(c, jsonObject.getString(1), Toast.LENGTH_LONG).show();
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(c, "e" + e.toString(), Toast.LENGTH_LONG).show();
                }

            }
        },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(c, "err" + error.toString(), Toast.LENGTH_LONG).show();

            }
        }
        );
        return stringRequest;
    }
    public static void Edit(Context c,String link,int UnitID,  String name, String surname,  String email,  String password,  String cell,  String yearMovedIn) throws UnsupportedEncodingException {

        name = URLEncoder.encode(name, "UTF8");
        surname = URLEncoder.encode(surname, "UTF8");
        email = URLEncoder.encode(email, "UTF8");
        password = URLEncoder.encode(password, "UTF8");
        cell = URLEncoder.encode(cell, "UTF8");
        yearMovedIn = URLEncoder.encode(yearMovedIn, "UTF8");


        String url = link + "Name=" + name + "&Surname=" + surname + "&email=" + email+ "&password=" + password+ "&cell=" + cell+ "&yearMovedIn=" + yearMovedIn + "&UnitID=" + UnitID +"&code=fsZopYSaqHxBSATKyK0rAvWwSV3r3H5adL887N1tyvggjeKcwGnTwg==";

        System.out.println(url);
        StringRequest stringRequest = StringRequest(c, url);
        RequestQueue requestQueue = Volley.newRequestQueue(c);
        requestQueue.add(stringRequest);
    }
    public static void Delete(Context c, String link, String ID) throws UnsupportedEncodingException {
        //ADD TO TEAM

        ID = URLEncoder.encode(ID, "UTF8");

        String url = link + "?ID="+ ID;

        System.out.println(url);

        StringRequest stringRequest = StringRequest(c, url);
        RequestQueue requestQueue = Volley.newRequestQueue(c);
        requestQueue.add(stringRequest);


    }
}
