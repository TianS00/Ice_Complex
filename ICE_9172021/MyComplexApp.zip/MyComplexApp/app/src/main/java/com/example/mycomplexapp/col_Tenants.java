package com.example.mycomplexapp;

public class col_Tenants {

    Object UnitID, Name, Surname, email, password, cell, yearMovedIn;
    public col_Tenants() {
    }

    public col_Tenants(Object unitID, Object name, Object surname, Object email, Object password, Object cell, Object yearMovedIn) {
        UnitID = unitID;
        Name = name;
        Surname = surname;
        this.email = email;
        this.password = password;
        this.cell = cell;
        this.yearMovedIn = yearMovedIn;
    }

    public Object getUnitID() {
        return UnitID;
    }

    public void setUnitID(Object unitID) {
        UnitID = unitID;
    }

    public Object getName() {
        return Name;
    }

    public void setName(Object name) {
        Name = name;
    }

    public Object getSurname() {
        return Surname;
    }

    public void setSurname(Object surname) {
        Surname = surname;
    }

    public Object getEmail() {
        return email;
    }

    public void setEmail(Object email) {
        this.email = email;
    }

    public Object getPassword() {
        return password;
    }

    public void setPassword(Object password) {
        this.password = password;
    }

    public Object getCell() {
        return cell;
    }

    public void setCell(Object cell) {
        this.cell = cell;
    }

    public Object getYearMovedIn() {
        return yearMovedIn;
    }

    public void setYearMovedIn(Object yearMovedIn) {
        this.yearMovedIn = yearMovedIn;
    }
}