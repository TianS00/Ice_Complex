package com.example.mycomplexapp;

import static com.example.mycomplexapp.MyApi.getObject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.widget.EditText;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Vector;

public class complaints extends AppCompatActivity {

    public static List<col_Complaint> colList_Complaint = new Vector<>();
    adapter_Complaint adapter_complaint;
    final Runnable r = () -> {

        adapter_complaint.notifyDataSetChanged();
        //    adapter_media.notifyDataSetChanged();

    };
    RequestQueue queue;
    public static int UnitID = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaints);
    EditText et = findViewById(R.id.etPost);

        colList_Complaint.clear();

        adapter_complaint = new adapter_Complaint(colList_Complaint, this);
        RecyclerView rv = findViewById(R.id.rvComplaints);
        rv.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        rv.setItemAnimator(new DefaultItemAnimator());
        rv.setAdapter(adapter_complaint);

        Handler handler = new Handler();
        RequestQueue queue = Volley.newRequestQueue(this);

        queue.add(getObject(new MyApi.SimpleCallback<JSONArray>() {
            @Override
            public void callback(JSONArray data) throws JSONException {

                for (int i = 0; i < data.length(); i++) {
                    JSONObject data2 = (JSONObject) data.get(i);

                    if(data2.get("UnitID").equals(UnitID)) {
                        col_Complaint obj = new col_Complaint();
                        obj.setUnitID(data2.get("UnitID"));
                        obj.setID(data2.get("ID"));
                        obj.setComplaint(data2.get("complaint"));
                        obj.setStatus(data2.get("status"));

                        colList_Complaint.add(obj);
                    }

                }
                handler.postDelayed(r, 777);
            }

        }, "https://prjapifunction20210915142516.azurewebsites.net/api/ViewAll_Complaint?code=2omNOftHsXZ93pIvez2hEImq6EqZxowhVB009YXVvBwCZ24hELxT3Q=="));











        findViewById(R.id.btnPost).setOnClickListener(v->{
            try {
                Add_Complaint(this,"https://prjapifunction20210915142516.azurewebsites.net/api/Complaints_Insert?",UnitID,
                        et.getText().toString(),"Not Handled");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        });
    }
    public static void Add_Complaint(Context c, String link, int UnitID, String complaint, String status) throws UnsupportedEncodingException {

        complaint = URLEncoder.encode(complaint, "UTF8");
        status = URLEncoder.encode(status, "UTF8");


        String url = link + "complaint=" + complaint + "&status=" + status + "&UnitID=" + UnitID +"&code=dV1XVedtgD5G6cbpTI4/j4Xfo6/i0pmgAJhpUcc2a4JmYDPEzNC4lA==";

        System.out.println(url);
        StringRequest stringRequest = MyApi.StringRequest(c, url);
        RequestQueue requestQueue = Volley.newRequestQueue(c);
        requestQueue.add(stringRequest);
    }
}