package com.example.mycomplexapp;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;

public class adapter_Complaint extends RecyclerView.Adapter<adapter_Complaint.MyViewHolder> {
    private final List<col_Complaint> colList;
    private final Context mContext;

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_media_item, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        col_Complaint obj = colList.get(position);

      //  holder.ID.setText(obj.getID());
        holder.complaint.setText(""+obj.getComplaint());
        holder.status.setText(""+obj.getStatus());

        holder.layout.setOnClickListener(v->{
            //updfate to handeld

                try {

                   Edit(mContext,"https://prjapifunction20210915142516.azurewebsites.net/api/Complaints_Update?", (Integer) obj.getUnitID(),
                            ""+obj.getComplaint(), "Handeld");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }

        });
    }

    public adapter_Complaint(List<col_Complaint> colList, Context mContext) {
        this.colList = colList;
        this.mContext = mContext;

    }
    public static void Edit(Context c,String link,int UnitID,  String complaint, String status) throws UnsupportedEncodingException {

        complaint = URLEncoder.encode(complaint, "UTF8");
        status = URLEncoder.encode(status, "UTF8");




        String url = link + "complaint=" + complaint + "&status=" + status +"&UnitID=" + UnitID +"&code=eXhO8AmWMa1c7QpDbLQ3lUmx60NoEI/zr5UPN6m1N09V92j97UBshQ==";

        System.out.println(url);
        StringRequest stringRequest = MyApi.StringRequest(c, url);
        RequestQueue requestQueue = Volley.newRequestQueue(c);
        requestQueue.add(stringRequest);
    }
    @Override
    public int getItemCount() {
        return colList.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder {//to hold all elements
        public TextView complaint, status;
    public ConstraintLayout layout;
        //Initialize Views
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);


            complaint = itemView.findViewById(R.id.txtComplaint);
            status = itemView.findViewById(R.id.txtStatus);
//            btnAction = itemView.findViewById(R.id.btnView_Media);
          //  ID = itemView.findViewById(R.id.txt);
            layout = itemView.findViewById(R.id.linearLayout);
        }

    }
}