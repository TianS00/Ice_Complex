package com.example.mycomplexapp;


import static com.example.mycomplexapp.MainActivity.ChangeActivity;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;



import java.util.List;

public class adapter_Tenants extends RecyclerView.Adapter<adapter_Tenants.MyViewHolder> {
    private final List<col_Tenants> colList;
    private final Context mContext;

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_booking_prices_item, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        col_Tenants obj = colList.get(position);

       // holder.ID.setText(obj.getID());
        holder.title.setText(""+obj.getName()+ " "+obj.getSurname() );
        holder.description.setText(""+obj.getYearMovedIn());
        holder.price.setText(""+obj.getCell());

        holder.layout.setOnClickListener(v ->{
            complaints.UnitID = (int) obj.getUnitID();
            ChangeActivity(complaints.class, (Activity) mContext);
        });

    }

    public adapter_Tenants(List<col_Tenants> colList, Context mContext) {
        this.colList = colList;
        this.mContext = mContext;

    }

    @Override
    public int getItemCount() {
        return colList.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder {//to hold all elements
        public ImageView mainImage;
        public Button btnAction;
        public ConstraintLayout layout;
        public TextView title, description, price, ID;

        //Initialize Views
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

           // mainImage = itemView.findViewById(R.id.mainImage_BP);
            title = itemView.findViewById(R.id.txtName);
            description = itemView.findViewById(R.id.txtDesc);
            price = itemView.findViewById(R.id.txtCell);

            layout = itemView.findViewById(R.id.linearLayout);


        }

    }
}