package com.example.mycomplexapp;

import static com.example.mycomplexapp.MyApi.getObject;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

public class Profile extends AppCompatActivity {


    public static int UserUnitID = 4;

    EditText etName, etSurname, etEmail, etPassword, etCell, etYearMovedIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        etName = findViewById(R.id.etName);
        etSurname = findViewById(R.id.etSurname);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etCell = findViewById(R.id.editTextNumber);
        etYearMovedIn = findViewById(R.id.etDate);
        LoadResidence();
        Button btnSave = findViewById(R.id.btnSave);
        btnSave.setOnClickListener(v -> {
            try {
                MyApi.Edit(this,"https://prjapifunction20210915142516.azurewebsites.net/api/Update?",UserUnitID,
                        etName.getText().toString(),etSurname.getText().toString(),etEmail.getText().toString(),etPassword.getText().toString(),etCell.getText().toString(),etYearMovedIn.getText().toString());
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        });
    }


    private void LoadResidence() {
//        ProgressDialog pb = helper_common.ShowLoadingDialog(this);
        RequestQueue queue = Volley.newRequestQueue(this);

        queue.add(getObject(new MyApi.SimpleCallback<JSONArray>() {
            @Override
            public void callback(JSONArray data) throws JSONException {
                for (int i = 0; i < data.length(); i++) {
                    JSONObject obj = (JSONObject) data.get(i);
                    if (obj.get("UnitID").equals(UserUnitID)) {
                        System.out.println(obj.get("UnitID"));
                        etName.setText("" + obj.get("Name"));
                        etSurname.setText("" + obj.get("Surname"));
                        etEmail.setText("" + obj.get("email"));
                        etPassword.setText("" + obj.get("password"));
                        etCell.setText("" + obj.get("cell"));
                        etYearMovedIn.setText("" + obj.get("yearMovedIn"));
//                        System.out.println(obj.get("Name"));
//                        System.out.println(obj.get("Surname"));
//                        System.out.println(obj.get("email"));
//                        System.out.println(obj.get("password"));
//                        System.out.println(obj.get("cell"));
//                        System.out.println(obj.get("yearMovedIn"));
                    }
                }
            }
        }, "https://prjapifunction20210915142516.azurewebsites.net/api/ViewAll?&code=eKfVXa/zF4tTjFtJNlKlq1h4QpG3andM3qeMV/g1nMW83HzUi64lRg=="));
    }
}
//                    if (data.getJSONArray("booking_prices").getJSONObject(i).get("ID").equals(ID)) {
//                            etEmail.setText("" + data.getJSONArray("booking_prices").getJSONObject(i).get("title"));
//                            etDesc.setText("" + data.getJSONArray("booking_prices").getJSONObject(i).get("description"));
//                            etPrice.setText("" + data.getJSONArray("booking_prices").getJSONObject(i).get("price"));
////                        pb.dismiss();
//                            }