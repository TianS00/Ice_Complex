package com.example.mycomplexapp;

import static com.example.mycomplexapp.MyApi.getObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.Vector;

public class MainActivity extends AppCompatActivity {

    public static List<col_Tenants> colList_Team = new Vector<>();
    adapter_Tenants adapter_team;
    final Runnable r = () -> {

        adapter_team.notifyDataSetChanged();
        //    adapter_media.notifyDataSetChanged();

    };
    RequestQueue queue;

    public static void ChangeActivity(Class target, Activity cur) {
        Handler handler = new Handler();
        handler.postDelayed(() -> cur.startActivity(new Intent(cur.getApplicationContext(), target)), 500);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        ChangeActivity(Profile.class, (Activity) this);

        colList_Team.clear();
        adapter_team = new adapter_Tenants(colList_Team, this);
        RecyclerView rv = findViewById(R.id.rvTenants);
        rv.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        rv.setItemAnimator(new DefaultItemAnimator());
        rv.setAdapter(adapter_team);

        Handler handler = new Handler();
        RequestQueue queue = Volley.newRequestQueue(this);

        queue.add(getObject(new MyApi.SimpleCallback<JSONArray>() {
            @Override
            public void callback(JSONArray data) throws JSONException {
                for (int i = 0; i < data.length(); i++) {
                    JSONObject data2 = (JSONObject) data.get(i);

                    col_Tenants obj = new col_Tenants();
                    obj.setUnitID(data2.get("UnitID"));
                    obj.setName(data2.get("Name"));
                    obj.setSurname(data2.get("Surname"));
                    obj.setEmail(data2.get("email"));
                    obj.setPassword(data2.get("password"));
                    obj.setCell(data2.get("cell"));
                    obj.setYearMovedIn(data2.get("yearMovedIn"));

                    colList_Team.add(obj);

                }
                handler.postDelayed(r, 777);
            }

        }, "https://prjapifunction20210915142516.azurewebsites.net/api/ViewAll?code=eKfVXa/zF4tTjFtJNlKlq1h4QpG3andM3qeMV/g1nMW83HzUi64lRg=="));


    }
}