package com.example.mycomplexapp;

public class col_Complaint {

    Object ID, complaint, status, UnitID;
    public col_Complaint() {
    }

    public col_Complaint(Object ID, Object complaint, Object status, Object unitID) {
        this.ID = ID;
        this.complaint = complaint;
        this.status = status;
        UnitID = unitID;
    }

    public Object getID() {
        return ID;
    }

    public void setID(Object ID) {
        this.ID = ID;
    }

    public Object getComplaint() {
        return complaint;
    }

    public void setComplaint(Object complaint) {
        this.complaint = complaint;
    }

    public Object getStatus() {
        return status;
    }

    public void setStatus(Object status) {
        this.status = status;
    }

    public Object getUnitID() {
        return UnitID;
    }

    public void setUnitID(Object unitID) {
        UnitID = unitID;
    }
}
